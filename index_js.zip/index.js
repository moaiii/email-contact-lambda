'use strict';
const sendgrid = require('./modules/SendGrid');
const request = require("request");


/**
 *
 * @param event
 * @param context
 * @param callback
 * @returns {string}
 */
const sendMail = function(event, context, callback) {

  /**
   * Re-mapping the SNS data
   * * */
  var data = JSON.parse(event.Records[0].Sns.Message);
  // var data = event;

  /**
   * Remap the data from the AWS analytics lambda
   * * */
  data.todaysDate = new Date().toDateString();
  data.month = formatThisMonth();
  data.overrideLength = formatTime(data.overrideLength);
  data.totalHoursOfMusicPlayed = totalHoursPlayed(data.secondsPlayed, data.activePlayers);
  data.averageHoursOfMusicPlayed = averageHoursPlayed(data.secondsPlayed);
  data.totalFeedbacks = getTotalFeedbacks(data.feedbacks);
  data.feedbackString = formatFeedbackString(data.feedbacks);
  data.refreshedMusic = convertNumTracksToHours(data.freshTracksAdded);
  data.headerName = (data.companyName === undefined) ? data.contactName : data.companyName;
  data.subject = (data.month + " music report for " + data.headerName);
  data.overrideScentence = getOverrideScentence(data.overrideLength);

  /* *
   * Final format of the object in the send grids required structure
   * * */
  let substitutions = {
    '-active players-': data.activePlayers.toString(),
    '-todays date-': data.todaysDate,
    '-total players-': data.totalPlayers.toString(),
    '-num overrides-': data.numOverrides.toString(),
    '-total played-': data.totalHoursOfMusicPlayed.toString(),
    '-average played-': data.averageHoursOfMusicPlayed.toString(),
    '-override length-': data.overrideLength.toString(),
    '-override scentence-': data.overrideScentence.toString(),
    '-month-': data.month,
    '-client name-': data.headerName,
    '-total feedbacks-': data.totalFeedbacks.toString(),
    '-feedback content-': data.feedbackString,
    '-fresh tracks-': data.refreshedMusic.toString(),
  };

  console.log(substitutions);

  /**
   * Call the Send grid API and send email...
   *
   * @type {SendGrid.SendGrid}
   * * */
  var sg = require('sendgrid')(sendgrid.api_key);

  var request = sg.emptyRequest({
    method: 'POST',
    path: '/v3/mail/send',
    body: {
      personalizations: [
        {
          to: [{ email: 'chris.m@ambie.fm' }],
          'substitutions': substitutions,
          subject: data.subject
        }
      ],
      from: { email: 'hello@ambie.fm' },
      'template_id': '19a3e8ff-b6ca-40f4-ae88-6af78f16cfaf'
    }
  });

  /**
   * Log email API feedback
   * * */
  sg.API(request, function (error, response) {

    if (error) console.log('Error response received');
    console.log('Response status code: ', response.statusCode);
    console.log('Response body: ', response.body);
    console.log('Response headers: ', response.headers);
  });

  return 'Message Sent! -' + request.body;
};


/**
 * Utility function for formating the time from seconds
 * to an string in hours and seconds format
 *
 * @param {Number} unformattedTime
 * @return {String}
 * * */
function formatTime(unformattedTime) {

  let formattedTime = '';

  if(unformattedTime === 0) {
    formattedTime = (0).toString();

  } else if(unformattedTime > 0 && unformattedTime < 1) {
    formattedTime = (unformattedTime * 60).toString() + ' minutes';

  } else {
    let minutes = Math.floor((unformattedTime * 60) % 60);
    let hours = Math.floor(unformattedTime) + 1;

    let prefix = (hours === 1 ? ' hour' : ' hours');

    formattedTime = hours;
  }

  return formattedTime;
}


/**
 * Utility function for formating the month
 *
 * @returns {string}
 * * */
function formatThisMonth() {

  var monthNames = ["January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"];

  let index = new Date().getMonth();
  let month = monthNames[index];

  return month;
}


/**
 * Utility function to get seconds into hours for total time played
 *
 * @param rawSeconds
 * @returns {String}
 * * */
function totalHoursPlayed(rawSeconds, noOfPlayers) {

  let hours = rawSeconds / (60 * 60);
  let playerHours = hours / (noOfPlayers * 31) ;
  let formattedHours = formatTime(playerHours);

  return formattedHours;
}


/**
 * Utility function to get average hours played per day of month
 *
 * @param rawSeconds
 * @returns {String}
 * * */
function averageHoursPlayed(rawSeconds) {

  let daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

  let index = new Date().getMonth();
  let daysThisMonth = daysInMonth[index];

  let hours = (rawSeconds / (60 * 60)) / daysThisMonth;
  let formattedHours = formatTime(hours);

  return formattedHours;
}


/**
 * Utility function to format the feedback into neater string
 *
 * @param rawFeedback
 * @returns {string}
 * * */
function formatFeedbackString(rawFeedback) {

  let formattedFeedback = "";

  var howManyFeedbacks = Object.keys(rawFeedback).length;

  if(howManyFeedbacks > 0) {
    for(var i = 0; i < howManyFeedbacks; i++) {
      var type = Object.keys(rawFeedback)[i];
      var value = rawFeedback[type];
      let feedback = " <p> &bull;  " + value + " - " + type + " </p> ";

      if(type !== '' || type.length !== 0) {
        formattedFeedback += feedback;
      }
    }
  }

  return formattedFeedback;
}


/**
 * Sum the amount of all feedbacks received
 *
 * @param rawFeedbacks
 * @returns {number}
 * * */
function getTotalFeedbacks(rawFeedbacks) {

  let totalFeedbacks = 0;

  for (var key in rawFeedbacks) {
    let feedback = rawFeedbacks[key];
    if(key !== '' || key.length !== 0) {
      totalFeedbacks += feedback;
    }
  }

  return totalFeedbacks;
}


/**
 * Convert fresh tracks added into the 'hours of new music' format
 *
 * @param {number} sumOfTracks
 * @returns {String}
 * * */
function convertNumTracksToHours(sumOfTracks) {

  let averageLengthOfTrack = 4 * 60;
  let totalSeconds = averageLengthOfTrack * sumOfTracks;
  let string = totalHoursPlayed(totalSeconds, 1);

  return string;
}

function prettifyCompanyName(uglyString) {

  let bracketIndex = uglyString.indexOf('[');

  if(bracketIndex >= 0) return uglyString.substr(0, bracketIndex);
}


function getOverrideScentence (length) {

  let scentence = "";
  let overrideLength = parseInt(length);

  if(overrideLength > 1) {
    scentence = "On average, each schedule change lasted for <span style=\"font-weight:bold;\">" + overrideLength + " hours</span>";
  } else if (overrideLength > 0 && overrideLength < 1) {
    scentence = "On average, each schedule change lasted for <span style=\"font-weight:bold;\">" + overrideLength + " minutes</span>";
  } else {
    scentence = "There were no over overrides to your playlists this month";
  }

  return scentence;
}


/**
 * Main Function Handler
 *
 * @param event
 * @param context
 * @param callback
 * * */
exports.handler = function(event, context, callback) {

  console.log('Sending email with Send Grid API...');
  sendMail(event,context,callback);
};